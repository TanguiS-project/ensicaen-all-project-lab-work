# OS TP03 - Generation d'une Courbe - STEIMETZ Tangui



## Compil command :
```c
$ make
```

## Execute program :
```c
$ ./bin/simple
```

## Result
in the output folder : prime_number.txt
in the terminal


## You may want to modify the max prime number :
go into the include/fsieve.h
modify the macro '#define NUMBER_MAX  1000' 
