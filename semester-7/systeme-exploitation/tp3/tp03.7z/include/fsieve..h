#ifndef __FSIEVE_HH__
#define __FSIEVE_HH__

#include <stdio.h>  /* printf() */
#include <stdlib.h> /* exit() and execl()*/
#include <unistd.h> /* fork() */
#include <sys/types.h> /* wait() */
#include <sys/wait.h> /* wait() */
#include <ctype.h>

#define OUTPUT_TEXT "output/prime_numbers.txt"
#define INPUT       1
#define OUTPUT      0
#define NUMBER_MAX  5000
#define TAB_CONVERT 4


void run_app_fsieve();

#endif /* __FSIEVE_HH__ */
