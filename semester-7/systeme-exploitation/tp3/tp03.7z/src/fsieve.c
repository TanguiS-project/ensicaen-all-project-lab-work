#include "fsieve..h"

static FILE* output;

static void handle_fatal_error(const char *msg)
{
    perror(msg);
    exit(EXIT_FAILURE);
}

static void manage_child ( int pipe_from_father[] )
{
    pid_t pid;
    int buff;
    int prime;
    int anonymous_pipe[2];

    read ( pipe_from_father[OUTPUT], &prime, sizeof ( int ) );
    if ( prime == -1 ) {
        exit ( EXIT_SUCCESS );
    }
    //printf ( "I am (%d)pid and i got the prime : %d\n", getpid(), prime );
    fprintf ( output, "%d ", prime );
    fflush(output);

    if ( pipe ( anonymous_pipe ) == -1 ) {
        handle_fatal_error("Error [pipe()]: ");
    }

    pid = fork();
    if ( pid == -1 ) {
        handle_fatal_error("Error [fork()]: ");
    } else if ( pid > 0 ) { // Parent
        close ( pipe_from_father[INPUT] );
        close ( anonymous_pipe[OUTPUT] );
        do {
            read ( pipe_from_father[OUTPUT], &buff, sizeof ( int ) );
            if ( buff % prime != 0 ) {
                write ( anonymous_pipe[INPUT], &buff, sizeof(int) );
            }
        } while ( buff != -1 );
        wait ( NULL );
    } else { // Child
        manage_child ( anonymous_pipe );
    }
    close ( pipe_from_father[OUTPUT] );
    close ( anonymous_pipe[INPUT] );
    exit ( EXIT_SUCCESS );
}

static void manage_parent()
{
    pid_t pid;
    int anonymous_pipe[2];
    int i;
    const int endl = -1;

    if ( pipe ( anonymous_pipe ) == -1 ) {
        handle_fatal_error("Error [pipe()]: ");
    }

    pid = fork();
    if ( pid == -1 ) {
        handle_fatal_error("Error [fork()]: ");
    } else if ( pid > 0 ) {
        close ( anonymous_pipe[OUTPUT] );
        for ( i = 2; i < NUMBER_MAX; i++ ) {
            write ( anonymous_pipe[INPUT], &i, sizeof(int) );
        }
        write ( anonymous_pipe[INPUT], &endl, sizeof(int) );
        close ( anonymous_pipe[INPUT] );
        wait(NULL);
    } else {
        manage_child ( anonymous_pipe );
    }
}

void run_app_fsieve()
{
    output = fopen ( OUTPUT_TEXT, "w" );
    manage_parent();
    fclose ( output );
}