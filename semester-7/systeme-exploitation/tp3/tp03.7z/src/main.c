#include "fsieve..h"

int main ( void )
{
    run_app_fsieve();
    exit(EXIT_SUCCESS);
}