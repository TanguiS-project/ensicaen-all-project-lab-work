STEIMETZ Tangui - Rapport tp05 systeme d'exploitation.

1. Executer le distributeur : 
command : {  $ chmod u+x ./bin/syrup_drink_dispenser  }
command : {  $ ./bin/syrup_drink_dispenser            }

2. Executer le programme 'monitor' pour avoir acces au distributeur : 
Pour compiler : make
Pour executer : ./monitor
-> Suivre les indications sur le terminal.

Pour clean : make clean
