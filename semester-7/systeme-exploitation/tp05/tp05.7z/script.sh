#!/bin/bash
for i in {0..26}
do
  ./bin/syrup_drink_dispenser &
  echo "$i"
  ./bin/monitor "$i" > test.txt
  sleep 3
  pkill syrup_drink_dis
done