#include <ctype.h>
#include <fcntl.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

#define SHARED_MEM_SIZE 776
#define STRING_SIZE 256
#define PASSWORD "Manon des sources"
#define WATER "water"
#define GRENADINE "grenadine"
#define MINT "mint"
#define OPEN "opened"
#define CLOSE "closed"
#define SEM_DIS "/saperlipopette-sem"
#define SHM_NAME "/saperlipopette"

typedef sem_t semaphore_t;

typedef struct monitor {
    int a;
    int b;
    char password[STRING_SIZE];
    char status[STRING_SIZE];
    char liquidType[STRING_SIZE];
}_monitor;

void putInt( _monitor* monitor );

void encryptPassword( const char *passwordToEncrypt, char* result, const int circ );

void putChar( const char* str, char* result );

void handleFatalError( const char *message );

void saveData( const _monitor* toSave, _monitor* redirect, semaphore_t* sem );

void writeData( _monitor* write, const _monitor* data, semaphore_t* sem);

semaphore_t* openSemaphore( const char *name );

void P( semaphore_t *sem );

void V( semaphore_t *sem );