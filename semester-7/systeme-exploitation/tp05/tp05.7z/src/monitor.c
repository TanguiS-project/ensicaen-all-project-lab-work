#include "monitor.h"
#include <string.h>

void putInt( _monitor* monitor ) {
    monitor->a = 0;
    monitor->b = 0;
}

void encryptPassword( const char *passwordToEncrypt, char* result, const int circ ) {
    int i;
    for ( i = 0; i < (int)strlen(passwordToEncrypt); i++ ) {
        if ( passwordToEncrypt[i] >= 'a' && passwordToEncrypt[i] <= 'z' ) {
            result[i] = ( ( passwordToEncrypt[i] - 'a' + circ ) % 26 ) + 'a';
        } else if ( passwordToEncrypt[i] >= 'A' && passwordToEncrypt[i] <= 'Z' ) {
            result[i] = ( ( passwordToEncrypt[i] - 'A' + circ ) % 26 ) + 'A';
        } else if ( passwordToEncrypt[i] == ' ' ) {
            result[i] = ' ';
        }
    }
    for ( ; i < STRING_SIZE; i++ ) {
        result[i] = '\0';
    }
}

void putChar( const char* str, char* result ) {
    int i;
    for ( i = 0; i < (int)strlen(str); i++ ) {
        result[i] = str[i];
    }
    for ( ; i < STRING_SIZE; i++ ) {
        result[i] = '\0';
    }
}

void saveData( const _monitor* toSave, _monitor* redirect, semaphore_t* sem )
{
    P(sem);
    strcpy( redirect->password, toSave->password );
    strcpy( redirect->status, toSave->status );
    strcpy( redirect->liquidType, toSave->liquidType );
    V(sem);
}

void writeData( _monitor* write, const _monitor* data, semaphore_t* sem )
{
    P(sem);
    strcpy( write->password, data->password );
    strcpy( write->status, data->status );
    strcpy( write->liquidType, data->liquidType );
    V(sem);
}

void handleFatalError( const char *message )
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}

semaphore_t* openSemaphore( const char *name )
{
    semaphore_t *sem = NULL;

    sem = sem_open(name, O_RDWR, S_IRUSR | S_IWUSR, 0);
    if (sem == SEM_FAILED) {
        handleFatalError("Error [sem_open()]: ");
    }
    return sem;
}

void P( semaphore_t *sem )
{
    int r = 0;

    r = sem_wait(sem);
    if (r < 0) {
        handleFatalError("Error [P()]: ");
    }
}

void V( semaphore_t *sem )
{
    int r = 0;

    sem_post(sem);
    if (r < 0) {
        handleFatalError("Error [V()]: ");
    }
}