#include "monitor.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

void displayCommand()
{
    printf( "--> Command : \n" );
    printf( "  > Open : o\n" );
    printf( "  > Close : c\n" );
    printf( "  > Water : w\n" );
    printf( "  > Mint : m\n" );
    printf( "  > Grenadine : g\n" );
    printf( "  > Quit : q\n" );
}

int main ( int argc, char** argv ) 
{
    _monitor monitor;
    _monitor *ptr;
    _monitor save;
    semaphore_t* sem;
    char cmd;
    int circ = 13;
    int shm;
    int loop = 1;

    encryptPassword( PASSWORD, monitor.password, circ );
    putChar( OPEN, monitor.status );

    shm = shm_open( SHM_NAME, O_RDWR, 0644 );
    
    ptr = (_monitor *)mmap( NULL, sizeof(_monitor), PROT_READ | PROT_WRITE, MAP_SHARED, shm, 0 );
    
    sem = openSemaphore( SEM_DIS );

    saveData( ptr, &save, sem );

    writeData( ptr, &monitor, sem  );


    printf( "--> Connected to the distributor (open by default) <--\n--> Enter a command <--\n" );
    while (loop) {
        displayCommand();
        if (scanf("%c", &cmd) != 1) {
            break;
        }
        fflush( stdin );
        fflush( stderr );
        fflush( stdout );
        switch ( toupper( cmd ) ) {
        case 'O':
            putChar( OPEN, monitor.status );
            printf( "        > Opened\n" );
            break;
        case 'C':
            putChar( CLOSE, monitor.status );
            printf( "        > Closed\n" );
            break;
        case 'W':
            putChar( WATER, monitor.liquidType );
            printf( "        > Water\n" );
            break;
        case 'G':
            putChar( GRENADINE, monitor.liquidType );
            printf( "        > Grenadine\n" );
            break;
        case 'M':
            putChar( MINT, monitor.liquidType );
            printf( "        > Mint\n" );
            break;
        case 'Q':
            printf( "        > Quit\n" );
            loop = 0;
            break;
        default:
            break;
        }
        writeData( ptr, &monitor, sem  );
    }

    sleep(1);
    writeData( ptr, &save, sem );
    munmap(ptr, SHARED_MEM_SIZE);
    return 1;
}