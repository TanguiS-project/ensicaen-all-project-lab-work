#include "cos_sin.h"


void run_app_to_display();