#include <stdio.h>     /* printf() */
#include <stdlib.h>    /* exit() and execl()*/
#include <unistd.h>    /* fork() */
#include <signal.h>    /* sigaction() */
#include <sys/types.h> /* pid_t */
#include <sys/wait.h>  /* wait() */
#include <string.h>    /* memset() */
#include <math.h>

#define NAME_SIN_FILE "output/sinus.txt"
#define NAME_COS_FILE "output/cosinus.txt"


void run_app_for_cos_sin_data();