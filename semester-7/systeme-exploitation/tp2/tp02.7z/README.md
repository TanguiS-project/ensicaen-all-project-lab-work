# OS TP01 - Generation d'une Courbe - STEIMETZ Tangui



## Compil command :
```c
$ make
```

## Execute program :
```c
$ ./bin/cossinGNU
```
then follow instructions
