#include "cos_sin.h"

#define TIMER 500000

typedef struct sigaction SIG;

static int angle_sin = 0;
static int angle_cos = 0;
static FILE* data_sinus;
static FILE* data_cosinus;

static double deg_to_radian(int deg)
{
    return (double)deg * M_PI / 180.;
}

static void handle_fatal_error_and_exit(const char *msg)
{
    perror(msg);
    exit(EXIT_FAILURE);
}

static void handle_sigalarm_sin(int signal)
{
    if ( signal == SIGALRM ) {
        printf ( "Fils 1 : (%d) sinus(%d) = %.2f\n", getpid(), angle_sin, sin(deg_to_radian(angle_sin)));
        fprintf ( data_sinus, "%d %.2f\n", angle_sin, sin(deg_to_radian(angle_sin)));
        angle_sin += 10;
    }
}

static void handle_sigalarm_cos(int signal)
{
    if ( signal == SIGALRM ) {
        printf ( "Fils 2 : (%d) sinus(%d) = %.2f\n", getpid(), angle_cos, cos(deg_to_radian(angle_cos)));
        fprintf ( data_cosinus, "%d %.2f\n", angle_cos, cos(deg_to_radian(angle_cos)));
        angle_cos += 10;
    }
}

static void manage_child_sin()
{
    SIG action_sin;

    memset(&action_sin, '\0', sizeof(action_sin));
    action_sin.sa_handler = &handle_sigalarm_sin;
    sigaction(SIGALRM, &action_sin, 0);
    data_sinus = fopen ( NAME_SIN_FILE, "w" );

    ualarm(TIMER, TIMER);

    while(angle_sin <= 360) {
        ualarm(TIMER, TIMER);
        pause();
    }
    fclose(data_sinus);
    exit(EXIT_SUCCESS);
}

static void manage_child_cos()
{
    SIG action_cos;
    memset(&action_cos, '\0', sizeof(action_cos));
    action_cos.sa_handler = &handle_sigalarm_cos;
    sigaction(SIGALRM, &action_cos, 0);
    data_cosinus = fopen ( NAME_COS_FILE, "w" );

    usleep ( 5 );
    ualarm(TIMER, TIMER);

    while(angle_cos <= 360) {
        ualarm(TIMER, TIMER);
        pause();
    }

    fclose ( data_cosinus );
    exit(EXIT_SUCCESS);
}

static void manage_parent()
{
    pid_t pid;
    pid_t pid_bis;

    pid = fork();
    if ( pid == -1 ) {
        handle_fatal_error_and_exit ( "Error [fork()]: " );
    } else if ( pid > 0 ) {
        pid_bis = fork();
        if ( pid_bis == -1 ) {
            handle_fatal_error_and_exit ( "Error [fork()]: " );
        } else if ( pid_bis == 0 )  {
            manage_child_cos();
        }
        wait(NULL);
        wait(NULL);
    } 
    else {
        manage_child_sin();
    }
}

void run_app_for_cos_sin_data()
{
    manage_parent();
}