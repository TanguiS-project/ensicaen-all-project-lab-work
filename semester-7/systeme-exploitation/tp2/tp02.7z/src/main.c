#include "cos_sin.h"
#include "cos_sin_g.h"

int main ( void )
{
    run_app_for_cos_sin_data();
    run_app_to_display();
    exit(EXIT_SUCCESS);
}