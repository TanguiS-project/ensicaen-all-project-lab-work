#include "cos_sin_g.h"

#define COMMAND_GNU_SIN "output/command_sin.gp"
#define COMMAND_GNU_COS "output/command_cos.gp"

static void create_gnuplot_files()
{
    FILE* gnu_command_sin = fopen(COMMAND_GNU_SIN, "w");
    FILE* gnu_command_cos = fopen(COMMAND_GNU_COS, "w");

    fprintf ( gnu_command_sin, "plot \"%s\" using 1:2 smooth csplines", NAME_SIN_FILE );
    fprintf ( gnu_command_cos, "plot \"%s\" using 1:2 smooth csplines", NAME_COS_FILE );

    fclose ( gnu_command_sin );
    fclose ( gnu_command_cos );
}

static void handle_fatal_error_and_exit(const char *msg)
{
    perror(msg);
    exit(EXIT_FAILURE);
}

static void manage_child_cos()
{
    printf ( "Fils 4 : (%d) : exec gnuplot on %s\n", getpid(), NAME_COS_FILE);
    execlp("gnuplot", "gnuplot", "-persist", COMMAND_GNU_SIN, (void*)0 );
    exit(EXIT_SUCCESS);
}

static void manage_child_sin()
{
    printf ( "Fils 3 : (%d) : exec gnuplot on %s\n", getpid(), NAME_SIN_FILE);
    execlp("gnuplot", "gnuplot", "-persist", COMMAND_GNU_COS, (void*)0 );
    exit(EXIT_SUCCESS);
}

static void manage_parent()
{
    create_gnuplot_files();
    pid_t pid;
    pid_t pid_bis;

    pid = fork();
    if ( pid == -1 ) {
        handle_fatal_error_and_exit ( "Error [fork()]: " );
    } else if ( pid > 0 ) {
        pid_bis = fork();
        if ( pid_bis == -1 ) {
            handle_fatal_error_and_exit ( "Error [fork()]: " );
        } else if ( pid_bis == 0 )  {
            manage_child_cos();
        }
        wait(NULL);
        wait(NULL);
    } 
    else {
        manage_child_sin();
    }
}


void run_app_to_display()
{
    manage_parent();
}