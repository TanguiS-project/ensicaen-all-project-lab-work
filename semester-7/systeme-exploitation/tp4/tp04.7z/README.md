# OS TP04 - Generation d'une Courbe - STEIMETZ Tangui



## Compil command :
```c
$ make
```

## Execute program :
```c
$ ./bin/matrix_product
```

## Some result
file : 'out$' shows some exec time on my computer with 8 threads

## Modify the number of thread :
go on 'matrix_product_multi.c' and modify the macro : "#define NUMBER_CORE 8', it will be equals to your number of thread

## Print the matrix :
go on 'matrix.h' and change the macro : '#define PRINT 0' -> put 1 instead

## Change the size of the matrix :
go on 'matrix.h' and change the macro '#define SIZE 5000'  
