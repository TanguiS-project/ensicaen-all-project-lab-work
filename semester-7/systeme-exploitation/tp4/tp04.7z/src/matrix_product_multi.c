#include "matrix.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>
#include <matrix.h>

#define NUMBER_CORE 8

typedef struct args_t {
	int tid;
	int* working_columns;
	matrix_t* m1;
	matrix_t* m2;
	matrix_t* result;
} args_t;

pthread_mutex_t mutex;

static void handle_pthread_error ( const char* err )
{
	perror ( err );
	exit ( EXIT_FAILURE );
}

static void kill_thread_args ( args_t* pargs )
{
	free ( pargs );
}

void* thread_working_on_columns ( void * vargp )
{
	unsigned int rows;
	unsigned int working_columns = ((args_t*)vargp)->tid;

	do {
		for ( rows = 0; rows < ((args_t*)vargp)->result->rows; rows++ ) {
			((args_t*)vargp)->result->matrix[rows][working_columns] = product_case ( rows, working_columns, ((args_t*)vargp)->m1, ((args_t*)vargp)->m2 );
			//printf ( "Working on rows = (%d), columns = (%d)\n", rows, working_columns );
		}
		working_columns += NUMBER_CORE;
	} while ( working_columns < ((args_t*)vargp)->result->columns );



	return NULL;
}

static void create_thread ( int* tid_args, pthread_t* tid, matrix_t* m1, matrix_t* m2, matrix_t* result, args_t* pargs )
{
	int i;
	for ( i = 0; i < NUMBER_CORE; i++ ) {
		tid_args[i] = i;
		pargs[i].m1 = m1;
		pargs[i].m2 = m2;
		pargs[i].result = result;
		pargs[i].tid = tid_args[i];
		if ( pthread_create ( &tid[i], NULL, thread_working_on_columns, &pargs[i] ) != 0 ) {
			handle_pthread_error ( "Error [pthread_create()]: " );
		}
	}
}

static matrix_t* product_matrix_multi( matrix_t *m1, matrix_t *m2 )
{
	unsigned int i;
	matrix_t* result;
	int tid_args[NUMBER_CORE];
	pthread_t tid[NUMBER_CORE];
	args_t pargs[NUMBER_CORE];

	if (m1->columns != m2->rows) {
		printf("Dimensions Error\n");
		return NULL;
	}
	result = init_matrix(m1->rows, m2->columns, 0);

	create_thread ( tid_args, tid, m1, m2, result, pargs );
	
  	for (i = 0; i < NUMBER_CORE; i++) {
        if ( pthread_join(tid[i], NULL) != 0 ) {
			handle_pthread_error ( "Error [pthread_join()]: " );
		}
	}

	return result;
}

void multi_thread(matrix_t *m1, matrix_t *m2)
{
    matrix_t *m3;
	clock_t c_before;
	clock_t c_after;
	time_t t_before;
	time_t t_after;

    c_before = clock();
	t_before = time(NULL);

	m3 = product_matrix_multi ( m1, m2 );

	t_after = time(NULL);
	c_after = clock();


    if (PRINT) {
		printf("\nProduct :\n");
		print_matrix(m3);
	}

	printf("\nClock_t -> %5.3f ticks (%f seconds)\n",
			 (float) (c_after - c_before),
			 (double) (c_after - c_before) / CLOCKS_PER_SEC);
	printf("Time_t  -> %5.3f seconds\n", difftime(t_after, t_before));

	free_matrix(m3->matrix);
	free(m3);
}