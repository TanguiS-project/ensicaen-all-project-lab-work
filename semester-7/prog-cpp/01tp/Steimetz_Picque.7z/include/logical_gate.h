#ifndef __LOGICAL_GATE_HH__
#define __LOGICAL_GATE_HH__
#include <iostream>

bool logical_gate ( bool first, bool second );

#endif //__LOGICAL_GATE_HH__