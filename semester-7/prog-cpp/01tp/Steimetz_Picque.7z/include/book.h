#ifndef __BOOK_HH__
#define __BOOK_HH__
#include <iostream>

using namespace std;

#define MAX_LENGTH_TITLE 50
#define NUMBER_BOOK 3

struct Book {
    char title[MAX_LENGTH_TITLE];
    int number_sheet;
};

int read_number_sheet();

void read_number_sheet( int* nb_sheet );

void read_number_sheet( int& nb_sheet );

void read_title_book ( char title[MAX_LENGTH_TITLE] );

Book read_book ();

void read_tab_book ( Book tab_book[], int length );

void display_book ( const Book* book );

void display_book ( const Book book[], int length );

void swap_number_sheet ( Book& first, Book& second );

Book& longest_book ( Book tab_book[], int length );

Book& shortest_book ( Book tab_book[], int length );

void run_app_library();

#endif //__BOOK_HH__