STEIMETZ Tangui - Rapport tp01 C++

1. sortie listing : x vaut 5

-> ligne 6 : la variable x est référencée par la variable r;
-> ligne 7 : on affecte à 'r' la valeur de y, donc 'x' est affectée à 'y' (référence);
-> ligne 8 : on affecte '5' à la référence 'r' donc 'x' aussi car référence;

2.1 ambiguous