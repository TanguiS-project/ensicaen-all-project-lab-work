#include "logical_gate.h"

//Variable static referente est accepte car presente dans le code brute, donc possede une addr

bool logical_gate ( bool first, bool second )
{
    return first && second;
}