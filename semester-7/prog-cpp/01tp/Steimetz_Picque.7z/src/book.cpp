#include "book.h"

static void manage_cin_error ( const char* err )
{
    cout << "ERROR : " << err << endl;
}

static bool is_valid ( int& i_to_test )
{
    //if not int ??
    if ( i_to_test <= 2 || i_to_test >= 2000 ) {
        manage_cin_error ( "not in range : ]2; 2000[" );
        i_to_test = 0;    
        cin.clear();
        cin.ignore();
        return false;
    }
    return true;
}

static void request_cin ( const char* request)
{
    cout << "Request : " << request << endl;
}

int read_number_sheet()
{
    int nb;
    do {
        request_cin("Enter number of page : ");
        cin >> nb;
    } while ( !is_valid ( nb ) );
    return nb;
}

void read_number_sheet( int* nb_sheet )
{
    int tmp;
    do {
        request_cin("Enter number of page : ");
        cin >> tmp;
    } while ( !is_valid ( tmp ) );
    *nb_sheet = tmp;
}

void read_number_sheet( int& nb_sheet )
{
    int tmp;
    do {
        request_cin("Enter number of page : ");
        cin.clear();
        cin >> tmp;
        cin.ignore();
    } while ( !is_valid ( tmp ) );
    nb_sheet = tmp;
}

void read_title_book ( char title[MAX_LENGTH_TITLE] )
{
    request_cin("Enter the title : ");
    cin.clear();
    cin.getline ( title, MAX_LENGTH_TITLE );
}

Book read_book ()
{
    Book book;
    read_number_sheet(book.number_sheet);
    read_title_book(book.title);
    return book;

}

void read_tab_book ( Book tab_book[], int length )
{
    int i;
    for ( i = 0; i < length; i++ ) {
        tab_book[i] = read_book();
        cout << endl;
    }
}

void display_book ( const Book* book )
{
    cout << "nombre de page : " << book->number_sheet << " |  titre : " << book->title << endl << endl; 
}

void display_book ( const Book book[], int length )
{
    int i;
    for ( i = 0; i < length; i++ ) {
        display_book ( &book[i] );
    }
}

void swap_number_sheet ( Book& first, Book& second )
{
    int tmp;
    tmp = first.number_sheet;
    first.number_sheet = second.number_sheet;
    second.number_sheet = tmp;
}

Book& longest_book ( Book tab_book[], int length )
{
    int i;
    Book* longest = &(tab_book[0]);
    for ( i = 0; i < length; i++ ) {
        if ( longest->number_sheet < tab_book[i].number_sheet ) {
            longest = &(tab_book[i]);
        }
    }
    Book& r_longest = *longest;
    return r_longest;
}

Book& shortest_book ( Book tab_book[], int length )
{
    int i;
    Book* shortest = &(tab_book[0]);
    for ( i = 0; i < length; i++ ) {
        if ( shortest->number_sheet > tab_book[i].number_sheet ) {
            shortest = &(tab_book[i]);
        }
    }
    Book& r_shortest = *shortest;
    return r_shortest;
}

void run_app_library()
{
    Book tab_book[NUMBER_BOOK];
    read_tab_book ( tab_book, NUMBER_BOOK );
    swap_number_sheet ( shortest_book ( tab_book, NUMBER_BOOK ), longest_book ( tab_book, NUMBER_BOOK ) );
    display_book ( tab_book, NUMBER_BOOK );
    Book& tmp_shortest = shortest_book ( tab_book, NUMBER_BOOK );
    Book& tmp_longest = longest_book ( tab_book, NUMBER_BOOK );
    swap_number_sheet ( tmp_shortest, tmp_longest );
    display_book ( tab_book, NUMBER_BOOK );

    //Q3 erreur ?
    //swap_number_sheet ( read_book(), read_book() );
    //error: cannot bind non-const lvalue reference of type ‘Book&’ to an rvalue of type ‘Book’

    
}