#include <iostream>
#include "book.h"
#include "logical_gate.h"

using namespace std;

int main ( void )
{
    //run_app_library();
    cout << logical_gate ( true, false ) << endl << logical_gate ( false, true ) << endl << logical_gate ( false, false ) << endl << logical_gate ( true, true ) << endl;
    exit ( EXIT_SUCCESS );
}