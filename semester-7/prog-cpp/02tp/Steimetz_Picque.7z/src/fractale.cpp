#include "Complex.h"
#include "Image.h"
#include <iostream>

#define N 10

double shadesGreenLeft ( int column, int max )
{
    static double increment = 1. / (double)max;
    return 1. - (double)column * increment;
}

double shadesRedRight ( int column, int max )
{
    static double increment = 1. / (double)max;
    return (double)column * increment;
}

static double pixelToComplex( int point, int length, double x1, double x2 ) //left - right | bas - haut
{
    return ( ( ( x2 - x1 ) * (double)point ) / (double)length ) + x1;
}

static int fractalSequence ( Complex c, Complex z0 )
{
    Complex z = z0;
    int i;
    for ( i = 0; i < N; i++ ) {
        z = z * z + c;
        if ( z.calcMod() > 4 ) {
            return i;
        }
    }
    return i;
}

void Mandelbrot( Image& image, double x1, double y1, double x2, double y2)
{
    for ( int x = 0; x < image.width(); x++ ) {
        for ( int y = 0; y < image.height(); y++ ) {
            int iters = fractalSequence( Complex ( pixelToComplex(x, image.width()-1, x1, x2), pixelToComplex(y, image.height()-1, y1, y2) ),
                                         Complex ( 0, 0 ) 
                                       );
            //printf("%f\n", ((double)N - (double)iters) / (double)N);
            //printf ( "%f %f\n", pixelToComplex(x, image.width()-1, x1, x2), pixelToComplex(y, image.height()-1, y1, y2) );
            if ( iters != N ) {
                image.setPixel ( x, y, 0., 0., ((double)iters - (double)N) / (double)N );
            }
        }
    }
}

void Julia( Image& image, double x1, double y1, double x2, double y2 )
{
    for ( int x = 0; x < image.width(); x++ ) {
        for ( int y = 0; y < image.height(); y++ ) {
            //Complex c( -0.038088, 0.9754633 );
            int iters = fractalSequence( Complex( -0.038088, 0.9754633 ), 
                                          Complex( pixelToComplex( x, image.width()-1, x1, x2 ), 
                                                   pixelToComplex( y, image.height()-1, y1, y2 ) 
                                                 ) 
                                       );
            if ( iters != N ) {
                image.setPixel ( x, y, 0., 0., ((double)iters - (double)N) / (double)N );
            }
        }
    }
}