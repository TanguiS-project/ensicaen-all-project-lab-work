/**
 * @file   example.cpp
 * @author Sebastien Fourey
 *
 * @brief  Sample code using the Image class
 */
#include <string.h>

#include "Complex.h"
#include "Image.h"
#include "fractale.h"
#define N 10

double shadesGreenLeft ( int column, int max )
{
    static double increment = 1. / (double)max;
    return 1. - (double)column * increment;
}

double shadesRedRight ( int column, int max )
{
    static double increment = 1. / (double)max;
    return (double)column * increment;
}

void Mandelbrot(Image &img, double x1, double y1, double x2, double y2) {
  int height = img.height();
  int width = img.width();
  for (int i = 0; i < height; i++) {
    for (int j = 0; j < width; j++) {
      Complex z = Complex(0, 0);
      double coorX = x1 * (double(width - 1 - j) / double(width - 1)) + x2 * (double(j) / double(width - 1));
      double coorY = y1 * double(height - 1 - i) / double(height - 1) + y2 * (double(i) / double(height - 1));
      Complex c(coorX, coorY);
      bool div = false;
      for (int n0 = 0; n0 < N; n0++) {
        z = z * z + c;
        if (z.calcMod() > 4) {
          img.setPixel(j, i, 0, double((N - n0)) / double(N), 0);
          div = true;
          break;
        }
      }
      if (!div) {
        img.setPixel(j, i, 0, 0, 0);
      }
    }
  }
}

void Julia(Image &img, double x1, double y1, double x2, double y2) {
  int height = img.height();
  int width = img.width();
  for (int i = 0; i < height; i++) {
    for (int j = 0; j < width; j++) {
      Complex c(-0.038088, 0.9754633);
      double coorX = x1 * (double(width - 1 - j) / double(width - 1)) + x2 * (double(j) / double(width - 1));
      double coorY = y1 * double(height - 1 - i) / double(height - 1) + y2 * (double(i) / double(height - 1));
      Complex z = Complex(coorX, coorY);
      bool div = false;
      for (int n0 = 0; n0 < N; n0++) {
        z = z * z + c;
        if (z.calcMod() > 4) {
          img.setPixel(j, i, 0, double((N - n0)) / double(N), 0);
          div = true;
          break;
        }
      }
      if (!div) {
        img.setPixel(j, i, 0, 0, 0);
      }
    }
  }
}

/* int main(int argc, char *argv[]) {
  if (argc < 5 || (argc > 1 && (strcmp(argv[1], "julia") && strcmp(argv[1], "mandelbrot")))) {
    std::cout << "Le programme s'utilise en faisant " << argv[0] << " julia|mandelbrot largeur hauteur fichier_sortie" << std::endl;
  } else {
    int width, height;
    sscanf(argv[2], "%d", &width);
    sscanf(argv[3], "%d", &height);

    Image image(width, height);

    if (!strcmp(argv[1], "julia")) {
      Julia(image, -2, -2, 2, 2);
    } else {
      Mandelbrot(image, -3, -3, 2, 3);
    }

    image.writeBMP(argv[4]);
  }
} */
