#include "Complex.h"
#include "Image.h"
#include "fractale.h"
#include <iostream>
using namespace std;

#define MANDELBROT "mandelbrot"
#define JULIA "julia"

static void manageInputError( const char* err)
{
    cout << "\n-------------\n" <<"Error input : " << err << "\n-------------\n\n";
    exit( EXIT_FAILURE );
}

int main ( int argc, char** argv )
{
    int inputWidth;
    int inputHeight;
    char* inputFractalMethod;
    char* outputImage;
    char* control;
    if( argc != 5 ) {
        if( argc < 5 ) {
            manageInputError( " >> Not Enough Argument <<" );
        } else {
            manageInputError( " >> Too Much Argument << " );
        }
    }
    if( strcmp( argv[1], MANDELBROT) != 0 && strcmp( argv[1], JULIA ) != 0 ) {
        manageInputError( " >> Wrong Fractal Method Input : mandelbrot || julia <<" );
    }
    inputFractalMethod = argv[1];
    inputWidth = (int)strtol( argv[2], &control, 10 );
    if( strcmp( control, argv[2] ) == 0 ) {
        manageInputError( " >> Wrong WIDTH Input : enter a integer type <<" );
    }
    inputHeight = (int)strtol( argv[3], &control, 10 );
    if( strcmp( control, argv[3] ) == 0 ) {
        manageInputError( " >> Wrong HEIGHT Input : enter a integer type <<" );
    }
    outputImage = argv[4];

    printf( "Arguments detected : %s, %d, %d, %s\n", inputFractalMethod, inputWidth, inputHeight, outputImage );

    Image img( inputWidth, inputHeight );
    //Vert ---> Rouge
    for( int x = 0; x < inputWidth; x++ ) {
        for( int y = 0; y < inputHeight; y++ ) {
            img.setPixel( x, y, shadesRedRight(x, inputWidth), shadesGreenLeft(x, inputHeight), 0. );
        }
    }
    if( strcmp( inputFractalMethod, JULIA ) == 0 ) {
        Julia( img, -2., -2., 2., 2. );
    } else {
        Mandelbrot( img, -3., -3., 2., 3. );
    }

    img.writeBMP( outputImage );
    exit( EXIT_SUCCESS );
    return 1;
}