#include <iostream>
#include "Complex.h"
using namespace std;

Complex foo ( Complex a, Complex b )
{
    Complex z(10, 10);
    z = a;
    z = b;
    return z;
}

int main ( void )
{
    cout << "Different appel de constructeur : " << endl;
    Complex test;
    cout << "test = " << test.toString() << endl;
    Complex test2(5.6, 6.66);
    cout << "test2 = " << test2.toString() << endl;
    Complex test3(test2);
    cout << "test3 = " << test3.toString() << endl;

    cout << endl << "Operateur =, entre test et test2" << endl;
    test = test2;
    cout << "test = test2 -> test = " << test.toString() << endl;

    cout << endl << "Les methodes basiques de la classe Complex : sur test" << endl;
    double a = test.getReal();
    cout << "a = " << a << endl;
    double b = test.getIm();
    cout << "b = " << b << endl;
    double mod = test.calcMod();
    cout << "mod_test = " << mod << endl;
    double arg = test.calcArg();
    cout << "arg_test = " << arg << endl;

    cout << endl << "Swap sur test : " << endl;
    test.swapParams();
    cout << "test = " << test.toString() << endl;
    cout << "test2 = " << test2.toString() << endl;
    cout << "test3 = " << test3.toString() << endl;

    cout << endl << "Surcharge d'operateur dans des fonctions : " << endl;
    Complex test4 = mult ( test3, test2 );
    cout << "mult(test3 , test2) = test4 = " << test4.toString() << endl;
    Complex test5 = sum ( test3, test2 );
    cout << "sum(test3 , test2) = test5 = " << test5.toString() << endl;
    Complex test6 = diff ( test3, test2 );
    cout << "diff(test3 , test2) = test6 = " << test6.toString() << endl;
    
    cout << endl << "Surcharge d'operateur dans des methodes : " << endl;
    test4 = test3 * test2;
    cout << "test3 * test2 = test4 = " << test4.toString() << endl;
    test5 = test3 + test2;
    cout << "test3 + test2 = test5 = " << test5.toString() << endl;
    test6 = test3 - test2;
    cout << "test3 - test2 = test6 = " << test6.toString() << endl;

    cout << endl << "Normalisation d'un complex : " << endl;
    Complex test7 = test;
    cout << "test7 = test = " << test7.toString() << endl;
    normalized ( test7 );
    cout << "norm(test7) = " << test7.toString() << endl;
    mod = test7.calcMod();
    cout << "mod_test7 = " << mod << endl;

    cout <<  endl <<"Rotation d'un complex : " << endl;
    Complex test8 = test;
    cout << "test8 = test = " << test8.toString() << endl;
    rotated ( test8, M_PI );
    cout << "rot(test8) = " << test8.toString() << endl;
    arg = test8.calcMod();
    cout << "arg_test8 = " << arg << " arg_test = " << test.calcArg() << " diff_arg = " << arg - test.calcArg() << endl;

    cout << endl << "Le complex avec le plus grand module : " << endl;
    Complex test9(1., 2.87);
    cout << "test9 = " << test9.toString() << endl;
    cout << "larger mod between test and test9 : " << largerMod ( test, test9 ).toString() << endl;

    Complex z2(8.88, 0.87);
    cout << "z2 = " << z2.toString() << endl;
    Complex z1 = largerMod ( z2, z2*z2 );
    cout << "z1 = largerMod ( z2, z2*z2 ) = " << z1.toString() << endl;

    int n = 5;
    cout << endl << "Racine " << n <<"-ieme de l'unite : " << endl;
    cout << "--INIT TABZ--" << endl;
    Complex* tabZ = new Complex[n]();
    cout << "--END INIT TABZ--" << endl << "--AFFECT ROOT--" << endl;
    affectRootUnit ( n, tabZ);
    cout << "TABZ display : " << endl;
    for ( int i = 0; i < n; i++ ) {
        cout << tabZ[i].toString() << endl;
    }
    delete[] tabZ;
    cout << endl << endl << endl;

    cout << endl << "Programme listenning 1 : " << endl;
    Complex z3(0, 0);
    Complex z4(1, 1);
    Complex z5(2, 2);
    cout << "Calling foo()" << endl;
    z5 = foo ( z3, z4 );
    cout << "End calling foo()" << endl;
    exit (EXIT_SUCCESS);
    return 1;
}