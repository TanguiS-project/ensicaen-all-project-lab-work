/**
 * @file   example.cpp
 * @author Sebastien Fourey
 *
 * @brief  Sample code using the Image class
 */
#include "Image.h"

int main()
{
  Image image(320, 200);

  for (int col = 0; col < 320; ++col) {
    for (int row = 0; row < 200; ++row) {
      image.setPixel(col, row, 1.0, 1.0, 1.0); // (1.0,1.0,1.0) == Blanc
    }
  }

  for (int col = 0; col < 320; ++col) {
    image.setPixel(col, 99, 1.0, 0, 0); // (1.0,0.0,0.0) == Rouge
    image.setPixel(col, 101, 1.0, 0, 0);
  }

  image.writeBMP("essai.bmp");
}
