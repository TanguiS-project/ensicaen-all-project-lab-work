/**
 * @file   Image.cpp
 * @author Sebastien Fourey
 *
 * @brief  Definition of the Image class
 *
 */
#include "Image.h"
#include <cstring>
using namespace std;

Image::Image(int width, int height) : _width(width), _height(height)
{
  if (width <= 0 || height <= 0) {
    _array = nullptr;
    return;
  }
  _array = new unsigned int[width * height];
  memset(_array, 0, width * height * sizeof(unsigned int));
}

Image::~Image()
{
  delete[] _array;
}

void Image::setPixel(int x, int y, double gray)
{
  setPixel(x, y, gray, gray, gray);
}

void Image::setPixel(int x, int y, double r, double g, double b)
{
  unsigned int lr = static_cast<unsigned int>(r * 255) & 0xFF;
  unsigned int lg = static_cast<unsigned int>(g * 255) & 0xFF;
  unsigned int lb = static_cast<unsigned int>(b * 255) & 0xFF;
  lg <<= 8;
  lr <<= 16;
  _array[y * _width + x] = lr | lg | lb;
}

void Image::writeBMPHeader(ofstream & f) const
{

  f.put('B'); // Magic number
  f.put('M');

  int ll = (((_width * 24) + 31) / 32) * 4; // Size of a row of pixels
  int bl = 14 + 40;                         // Size of header

  writeInt(bl + (ll * _height), f); // Total file size
  writeShort(0, f);                 // Reserved
  writeShort(0, f);                 // Reserved.
  writeInt(bl, f);                  // Position of data

  writeInt(40, f); // Size of next header
  writeInt(_width, f);
  writeInt(_height, f);
  writeShort(1, f); // Number of planes

  writeShort(24, f); // Nombre de bits par pixel.

  writeInt(0, f);            // Compression type (none)
  writeInt(ll * _height, f); // Image size
  writeInt(75 * 39, f);      // Horizontal resolution
  writeInt(75 * 39, f);      // Vertical resolution
  writeInt(0, f);            // Number of colors used
  writeInt(0, f);            // Number of important colors
}

void Image::writeBMPData(ofstream & f) const
{
  int line_size = ((_width + 3) / 4) * 4;
  for (int i = _height - 1; i >= 0; i--) {
    int j;
    for (j = 0; j < _width; j++) {
      f.put(static_cast<unsigned char>(_array[i * _width + j] & 0xff));
      f.put(static_cast<unsigned char>(_array[i * _width + j] >> 8) & 0xFF);
      f.put(static_cast<unsigned char>(_array[i * _width + j] >> 16) & 0xFF);
    }
    for (; j < line_size; j++)
      f.put(static_cast<unsigned char>(0));
  }
}

bool Image::writeBMP(const char * filename) const
{
  ofstream file;
  file.open(filename);
  if (!file) {
    cerr << "Cannot create " << filename << endl;
    return false;
  }
  writeBMPHeader(file);
  writeBMPData(file);
  file.close();
  return true;
}

void Image::writeInt(int i, ofstream & f)
{
  unsigned char b0, b1, b2, b3;
  b0 = (((unsigned int)i)) & 0xFF;
  b1 = (((unsigned int)i) >> 8) & 0xFF;
  b2 = (((unsigned int)i) >> 16) & 0xFF;
  b3 = (((unsigned int)i) >> 24) & 0xFF;
  f.put(b0);
  f.put(b1);
  f.put(b2);
  f.put(b3);
}

void Image::writeShort(short i, ofstream & f)
{
  unsigned char b0, b1;
  b0 = (((unsigned int)i)) & 0xFF;
  b1 = (((unsigned int)i) >> 8) & 0xFF;
  f.put(b0);
  f.put(b1);
}
