#include "Complex.h"
using namespace std;

Complex::Complex(const double a, const double b)
    : _a(a), _b(b)
{  
/*     if ( a == .0 && b  == 0. ) {
        cout << "    +++Complex()" << endl;
    } else {
        cout << "    +++Complex(" << a << "," << b << ")" << endl;
    } */
}

Complex::Complex(const Complex& z)
    : _a(z._a), _b(z._b) 
{
    //cout << "    rrrComplex(" << _a << "+i." << _b << ")" << endl;
}

Complex::~Complex() 
{ 
    //cout << "    ---Complex(" << _a << "+i." << _b << ")" << endl;
}

Complex& Complex::operator=(const Complex& z) 
{
    _a = z._a;
    _b = z._b; 
    //cout << "    op=Complex(" << _a << "+i." << _b << ")" << endl;
    return *this; 
}

Complex operator*( const Complex& z1, const Complex& z2 )
{
    return Complex( z1.getReal()*z2.getReal() - z1.getIm()*z2.getIm(), z1.getReal()*z2.getIm() + z1.getIm()*z2.getReal() );
} 

Complex operator+( const Complex& z1, const Complex& z2 )
{
    return Complex( z1.getReal() + z2.getReal(), z1.getIm() + z2.getIm() );
}

Complex operator-( const Complex& z1, const Complex& z2 )
{
    return Complex( z1.getReal() - z2.getReal(), z1.getIm() - z2.getIm() );
}

double Complex::getReal() const { return _a; }

double Complex::getIm() const { return _b; }

double Complex::calcMod() const { return ( sqrt ( (_a*_a) + (_b*_b) ) ); }

double Complex::calcArg() const { return ( atan2( _b, _a ) ); }

string Complex::toString() const 
{ 
    return "<<" + to_string(_a) + "+i." + to_string(_b) + ">>"; 
}

void Complex::swapParams()
{
    double tmp = _a;
    _a = _b;
    _b = tmp;
}

Complex mult( const Complex& z1, const Complex& z2 )//Appel implicit au cpy constructor
{
    return Complex( z1.getReal()*z2.getReal() - z1.getIm()*z2.getIm(), z1.getReal()*z2.getIm() + z1.getIm()*z2.getReal() );
}

Complex sum (const Complex& z1, const Complex& z2)
{
    return Complex( z1.getReal() + z2.getReal(), z1.getIm() + z2.getIm() );
}

Complex diff (const Complex& z1, const Complex& z2)
{
    return Complex( z1.getReal() - z2.getReal(), z1.getIm() - z2.getIm() );
}

/*
// Erreur
Complex diff (const Complex& z1, const Complex& z2)
{
    Complex tmp(z1._a - z2._b, z1._a - z2._b);
    return tmp;
}
*/

// It is not possible, because there already an other constructor with the same parameters.
// But we could add a 'fake'/'useless' parameters like : (double mod, double arg, int).

// It is smoother to overload the operators.

void normalized ( Complex& z)
{
    z = Complex ( z.getReal() / z.calcMod(), z.getIm() / z.calcMod() );
}

void rotated ( Complex& z, double teta )
{
    if ( z.getReal() == 0 && z.getIm() == 0 ) {
        return;
    } 

    double real = z.getReal() * cos(teta) - z.getIm() * sin ( teta );
    double im = z.getReal() * sin ( teta ) + z.getIm() * cos ( teta );

    z = Complex ( real, im );

}

Complex largerMod ( const Complex& z1, const Complex& z2 )
{
    if ( z1.calcMod() > z2.calcMod() ) {
        return z1;
    }
    return z2;
}

void affectRootUnit ( const int n, Complex* tabZ )
{
    const double teta0 = ( 2. * M_PI ) / (double)n;
    tabZ[0] = Complex(1, 0);
    for ( int k = 1; k < n; k++ ) {
        tabZ[k] = tabZ[k-1];
        rotated ( tabZ[k], teta0 );
    }
}