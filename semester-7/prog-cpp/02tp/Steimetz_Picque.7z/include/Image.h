/**
 * @file   Image.h
 * @author Sebastien Fourey
 *
 * @brief Declaration the Image class
 *
 */
#ifndef IMAGE_H
#define IMAGE_H

#include <fstream>
#include <iostream>

class Image {

public:
  /**
   * Construct an image with given size.
   */
  Image(int width, int height);

  ~Image();

  inline int width() const;

  inline int height() const;

  /**
   * Change the value of a pixel with a gray value in [0..1]
   */
  void setPixel(int x, int y, double gray);

  /**
   * Change the value of a pixel with an RGB (Red, Green, Blue) triple in [0..1]^3
   */
  void setPixel(int x, int y, double red, double green, double blue);

  /**
   * Save the image in a BMP file
   */
  bool writeBMP(const char * filename) const;

private:
  int _width;
  int _height;
  unsigned int * _array;

private:
  /**
   * Write an integer in a file (as little-endian).
   */
  static void writeInt(int i, std::ofstream & f);

  /**
   * Write a two-byte integer in a file (as little-endian).
   */
  static void writeShort(short s, std::ofstream & f);

  void writeBMPHeader(std::ofstream & f) const;

  void writeBMPData(std::ofstream & f) const;
};

/*
 * Inline methods
 */

int Image::width() const
{
  return _width;
}

int Image::height() const
{
  return _height;
}

#endif // ifndef IMAGE_H
