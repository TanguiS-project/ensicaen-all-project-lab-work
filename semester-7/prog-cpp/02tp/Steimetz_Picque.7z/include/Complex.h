#ifndef __COMPLEX_HH__
#define __COMPLEX_HH__
#include <iostream>
#include <cmath>
#include <cstring>

class Complex {
    double _a;
    double _b;
    public:
        explicit Complex(const double a = .0, const double b = .0);
        Complex(const Complex& z); //Constructeur par recopie
        ~Complex();
        Complex& operator=(const Complex& z);
        double getReal() const;
        double getIm() const;
        double calcMod() const;
        double calcArg() const;
        std::string toString() const;
        void swapParams();
};

Complex operator*( const Complex& z1, const Complex& z2 );
Complex operator+( const Complex& z1, const Complex& z2 );
Complex operator-( const Complex& z1, const Complex& z2 );

Complex mult (const Complex& z1, const Complex& z2);

Complex sum (const Complex& z1, const Complex& z2);

Complex diff (const Complex& z1, const Complex& z2);

void normalized ( Complex& z);

void rotated ( Complex& z, double teta );

Complex largerMod ( const Complex& z1, const Complex& z2 );

void affectRootUnit ( int n, Complex* tabZ );


#endif // __COMPLEX_HH__