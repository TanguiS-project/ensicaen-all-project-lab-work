#ifndef __FRACTALE_HH__
#define __FRACTALE_HH__
#include "Complex.h"
#include "Image.h"


double shadesGreenLeft ( int column, int max );

double shadesRedRight ( int column, int max );

void Mandelbrot( Image& image, double x1, double y1, double x2, double y2);

void Julia ( Image& image, double x1, double y1, double x2, double y2 );

#endif // __FRACTALE_HH__