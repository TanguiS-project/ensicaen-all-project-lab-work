#include "Matrix.h"

using namespace std;

/**
 * @brief Construct a new Matrix:: Matrix object
 * 
 */
Matrix::Matrix() : _matrix(nullptr), _rows(0), _columns(0)
{
}

/**
 * @brief Construct a new Matrix:: Matrix object
 * 
 * @param rows const int 
 * @param columns const int 
 */
Matrix::Matrix( const int rows, const int columns) : _rows(rows), _columns(columns)
{
    _matrix = new double[rows * columns]();

}

/**
 * @brief Construct a new Matrix:: Matrix object
 * 
 * @param rows const int 
 * @param columns const int 
 * @param table const int *
 */
Matrix::Matrix( const int rows, const int columns, const double *table) : _rows(rows), _columns(columns)
{
    _matrix = new double[rows * columns];
    for (int i = 0; i < rows; i++)
    {
        memcpy(_matrix + i * columns, table + i * columns, columns * sizeof(double));
    }
}

/**
 * @brief Copy construct a new Matrix:: Matrix object
 * 
 * @param matrix const Matrix
 */
Matrix::Matrix(const Matrix &matrix) : _rows(matrix._rows), _columns(matrix._columns)
{
    _matrix = new double[matrix._rows * matrix._columns];
    for (int i = 0; i < matrix._rows; i++)
    {
        memcpy(_matrix + i * matrix._columns, matrix._matrix + i * matrix._columns, matrix._columns * sizeof(double));
    }
}

/**
 * @brief Move copy construct a new Matrix:: Matrix object
 * 
 * @param matrix Matrix 
 */
Matrix::Matrix( Matrix && matrix )
{
    _rows = matrix._rows;
    _columns = matrix._columns;
    _matrix = matrix._matrix;
    matrix._rows = 0;
    matrix._columns = 0;
    matrix._matrix = nullptr;
    cout << "const&& "<< _rows << _columns << endl;
}

/**
 * @brief Destroy the Matrix:: Matrix object
 * 
 */
Matrix::~Matrix()
{
    delete[] _matrix; //Don't need to take care the case if _matrix is null
}

/**
 * @brief the assignement operator for matrix 
 * 
 * @param matrix const Matrix
 * @return Matrix& 
 */
Matrix & Matrix::operator=( const Matrix &matrix)
{
    _rows = matrix._rows;
    _columns = matrix._columns;
    delete[] _matrix;                                       // if the matrix already exist 
    _matrix = new double[matrix._rows * matrix._columns];
    for ( int i = 0; i < matrix._rows; i++ )
    {
        memcpy(_matrix + i * matrix._columns, matrix._matrix + i * matrix._columns, matrix._columns * sizeof(double));
    }
    return *this;
}

/**
 * @brief the move assignement operator for matrix 
 * 
 * @param matrix const Matrix
 * @return Matrix& 
 */
Matrix & Matrix::operator=( Matrix && matrix)
{
    cout << "op&& "<< _rows << _columns << endl;
    delete[] _matrix;
    _rows = matrix._rows;
    _columns = matrix._columns;
    _matrix = matrix._matrix;
    matrix._columns = 0;
    matrix._rows = 0;
    matrix._matrix = nullptr;
    return *this;
}

/**
 * @brief Square brakets operator
 * 
 * @param rows const
 * @return double* the pointer of the aked line
 */
double * Matrix::operator[]( const int rows )
{
    if ( _rows - 1 < rows  || rows < 0) {
        throw "number of rows is not in the matrix";
    }
    return ( _matrix + rows *_columns );
}

/**
 * @brief Parenthesis operator
 * 
 * @param rows const int 
 * @param columns const int 
 * @return double& a matrix's value coefficient  
 */
double & Matrix::operator()( const int rows, const int columns )
{
    if ( _rows < rows || rows < 0 ) {
        throw "number of rows is not in the martix";
    }
    if ( _columns < columns ||  columns < 0) {
        throw "number of columns is not in the matrix";
    }
    return _matrix[ rows * _columns + columns ];
}

/**
 * @brief Parenthesis operator
 * 
 * @param rows const int 
 * @param columns const int 
 * @return double a matrix's value coefficient  
 */
double Matrix::operator()( const int rows, const int columns ) const /*the const is written to use const matrices after when matrices don't need to be changed*/
{
    if ( _rows < rows || rows < 0 ) {
        throw "number rows of is not in the martix";
    }
    if ( _columns < columns ||  columns < 0) {
        throw "number columns of is not in the matrix";
    }
    return _matrix[ rows * _columns + columns ];
}

/**
 * @brief Addition between matrices
 * 
 * @param matrix const Matrix & 
 * @return Matrix 
 */
Matrix Matrix::operator+( const Matrix & matrix ) const //matrix's attributs are not changed 
{
    if ( _rows != matrix._rows || _columns != matrix._columns ) {
        throw "matrices have diferent dimention";
    }
    Matrix newMatrix( *this );
    for ( int i = 0; i < _rows; i++ ) {
        for ( int j = 0; j < _columns; j++ ) {
            newMatrix( i,j ) = (*this)(i,j) + matrix(i,j); 
        }
    }
    return newMatrix;
}

/**
 * @brief Substraction between matrices
 * 
 * @param matrix const Matrix &
 * @return Matrix 
 */
Matrix Matrix::operator-( const Matrix & matrix ) const
{
    if ( _rows != matrix._rows || _columns != matrix._columns ) {
        throw "matrices have diferent dimention";
    }
    Matrix newMatrix( *this );
    for ( int i = 0; i < _rows; i++ ) {
        for ( int j = 0; j < _columns; j++ ) {
            newMatrix( i,j ) = (*this)(i,j) - matrix(i,j); 
        }
    }
    return newMatrix;
}

/**
 * @brief Unar operation
 * 
 * @return Matrix 
 */
Matrix Matrix::operator-() const
{   
    if ( _rows == 0 || _columns == 0 ) {
        throw "matrix is empty";
    }
    Matrix newMatrix( *this );
    for ( int i = 0; i < _rows; i++ ) {
        for ( int j = 0; j < _columns; j++ ) {
            newMatrix( i,j ) = -( (*this)(i,j) ); 
        }
    }
    return newMatrix;
} 

/**
 * @brief Product operator 
 * 
 * @param matrix const Matrix &
 * @return Matrix 
 */
Matrix Matrix::operator*( const Matrix & matrix ) const
{
    if ( _rows != matrix._columns  ) {
        throw "matrices can't be multiplied";
    }
    Matrix newMatrix( _rows, matrix._columns );
    for ( int i = 0; i < _rows; i++ ) {
        for ( int j = 0; j < matrix._columns; j++ ) {
            for ( int k = 0; k < _rows; k++ ) {
                newMatrix( i, j ) += (*this)( i, k ) * matrix( k, j ); 
            }
        }
    }
    return newMatrix;
}

/**
 * @brief Test if a matrix is a sqare matrix
 * 
 * @return bool
 */
bool Matrix::testSquareMatrix() const
{
    return _columns == _rows;
}

/**
 * @brief get a transpose matrix
 * 
 * @return Matrix 
 */
Matrix Matrix::getTranspose() const
{
    Matrix newMatrix( _columns, _rows );
    for (int i = 0; i < _columns; i++ ) {
        for (int j = 0; j <= _rows; j++ ) {
            newMatrix( i, j ) = (*this)( j, i );
        }
    }
    return newMatrix;
}

/**
 * @brief display a matrix in a output flux
 * 
 * @param out 
 * @param matrix 
 * @return ostream& 
 */
ostream &operator<<(ostream &out, const Matrix &matrix)
{
    out << "[";
    for (int i = 0; i < matrix._rows; i++)
    {
        out << " [ ";
        for (int j = 0; j < matrix._columns; j++)
        {
            out << matrix._matrix[i * matrix._columns + j];
            if (j != matrix._columns - 1)
            {
                out << ", ";
            }
        }
        out << " ]";
        if (i != matrix._rows - 1)
        {
            out << ",";
        }
    }
    out << " ]";
    return out;
}

/**
 * @brief display a matrix in a input flux
 * 
 * @param in 
 * @param matrix 
 * @return istream& 
 */
istream &operator>>( istream & in, Matrix & matrix )
{
    int columns, rows;
    cout << "Enter the number of line then the number of column" << endl;
    in >> rows >> columns;
    matrix = Matrix( rows, columns );
    for ( int i = 0; i < matrix._rows; i++ ) {
        for ( int j = 0; j < matrix._columns; j++ ) {
            cout << "value for the row " << i+1 << ", the column " << j+1 << endl;
            in >> matrix( i, j );
        }
    }
    cout << matrix << endl;
    return in;

}


/**
 * @brief Create a identity matrix
 * 
 * @param size const int
 * @return Matrix 
 */
Matrix createId( const int size )
{
    Matrix id( size, size );
    for (int i = 0; i < size; i++ ) {
        id(i,i) = 1;
    }
    return id;
}


/*--------------FACULTATIF--------------*/

/**
 * @brief test is a matrix is null with an erros coefficient
 * 
 * @param epsilon 
 * @return bool 
 */
bool Matrix::isNull( const double epsilon )
{
    for ( int i = 0; i < _rows; i++ ) {
        for ( int j = 0; j < _columns; j++ ) {
            if ( (*this)(i,j) > epsilon || (*this)(i,j) < -epsilon ) {
                return false;
            }
        }
    }
    return true;
}

/**
 * @brief Create a identity matrix thank to a matrix's size
 * 
 * @return Matrix 
 */
Matrix Matrix::createId() const
{
    if ( !(*this).testSquareMatrix() ) {
        throw "the matrix is not square";
    }
    Matrix id( _rows, _rows );
    for (int i = 0; i < _rows; i++ ) {
        id(i,i) = 1;
    }
    return id;
}

/**
 * @brief get the reversed matrix
 * 
 * @param M const Matrix
 * @param n 
 * @param epsilon 
 * @return Matrix 
 */
Matrix inverse( const Matrix & M, const int n, const double epsilon )
{
    if ( !M.testSquareMatrix() ) {
        throw "the matrix is not square";
    }
    Matrix A, Id;
    Matrix temp, reverse;
    bool isReversable = false;

    Id = M.createId();
    A = Id - M;

    if ( A.isNull( epsilon ) ) {
        throw "matrix can't be reversted";
    }

    temp = A;
    reverse = temp + Id;

    for ( int k = 2; k <= n; k++ ) {
        temp = temp *A;
        reverse = reverse + temp;
        if ( temp.isNull( epsilon ) ) {
            isReversable = true;
        }
    }
    if ( isReversable ) {
        return reverse;
    } else {
        throw "matrix can't be reversted";  
    }
}