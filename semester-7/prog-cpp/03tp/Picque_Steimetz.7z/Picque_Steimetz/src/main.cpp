#include "Matrix.h"

using namespace std;

void foo( Matrix ) 
{

}

int main()
{
    double table[] = {1., 2., 3., 4., 5., 6.};
    double table1[] = {8., 4., 12., 45., 65., 75.};
    double table2[] = {0.2, 0.15, .36, -0.16, -0.158, -0.245};
    double tableTest[] = { 5./10., -1./4., -1./8., -5./7., 1., -2./10., -3./10., -3/8., 8./10. }; 

    Matrix mat;
    Matrix mat2(5, 2);
    Matrix mat3(2, 3, table);
    Matrix mat4(mat3);
    Matrix mat10(2, 3, table2 );
    Matrix test( 3, 3, tableTest );
    Matrix reverse;
    mat = mat3;
    cout << mat2 << endl;
    cout << mat3 << endl;
    cout << mat4 << endl;
    cout << mat << endl;
    mat4 = Matrix( 3, 2, table1 );
    mat = mat4; 
    cout << mat << endl;

    cout << "\n-----------Hooks operation-----------" << endl;
    cout << "good conditions" << endl;
    try {
        cout << mat[2] [0] << endl;
    } catch (const char* err) {
        cerr << err << endl; 
    }
    cout << "exception" << endl;
    try {
    cout << mat[19] [0] << endl;
    } catch (const char* err){
        cerr << err << endl; 
    }

    cout << "\n-----------Parenthesis operation-----------" << endl;
    cout << "good conditions" << endl;
    try {
    cout << mat(2,0) << endl;
    } catch (const char* err){
        cerr << err << endl; 
    }
    mat(2,0) = 5;
    cout << mat(2,0) << endl;
    cout << "exception" << endl;
    try {
    cout << mat(1,45) << endl;
    } catch (const char* err){
        cerr << err << endl; 
    }

    cout << "\n-----------Addition operation-----------" << endl;
    cout << "good conditions" << endl;
    mat2 = Matrix( 3, 2, table );
    cout << mat << endl << mat2 << endl << mat + mat2 << endl;
    cout << "exception" << endl;
    Matrix m = createId(10);
    try {
        cout << mat2 + m << endl;
    } catch (const char* err){
        cerr << err << endl; 
    }

    cout << "\n-----------Substraction operation-----------" << endl;
    cout << "good conditions" << endl;
    cout << mat << endl << mat2 << endl << mat - mat2 << endl;
    cout << "exception" << endl;
    try {
        cout << mat2 - m << endl;
    } catch (const char* err){
        cerr << err << endl; 
    }


    cout << "\n-----------Unar operation-----------" << endl;
    cout << "good conditions" << endl;
    cout << mat << endl << (- mat) << endl;
    cout << "exception" << endl;
    try {
        cout << -(Matrix()) << endl;
    } catch (const char* err){
        cerr << err << endl; 
    }

    cout << "\n-----------Product operation-----------" << endl;
    cout << "good conditions" << endl;
    mat = Matrix( 2, 2, table );
    mat2 = Matrix( 2, 2, table1 );
    cout << mat << endl << mat2 << endl << mat * mat2 << endl;
    cout << "exception" << endl;
    try {
        cout << mat2 * mat3 << endl;
    } catch (const char* err){
        cerr << err << endl; 
    }


    cout << "\n-----------iostream operation-----------" << endl;
    cin >> mat4;

    cout << "\n-----------Test square matrix-----------" << endl;
    cout << mat << endl << mat.testSquareMatrix() << endl;
    cout << mat3 << endl << mat3.testSquareMatrix() << endl;

    
    cout << "\n-----------Transpose matrix-----------" << endl;
    cout << mat << endl << mat.getTranspose() << endl;
    cout << mat3 << endl << mat3.getTranspose() << endl;

    cout << "\n-----------idendity matrix-----------" << endl;
    cout << createId( 5 ) << endl; 

    cout << "\n-----------Test move-----------" << endl;
    Matrix a,b,c;
    Matrix d = a * b ;
    c = a * b;
    foo ( c * c );

    cout << "\n-----------Null matrix-----------" << endl;
    cout << createId(5) << endl;
    cout << "the matrix is null : " <<  createId(5).isNull(0.5) << endl;
    cout << mat << endl;
    cout << "the matrix is null : " << mat.isNull(0.5) << endl;
    cout << mat10 << endl;
    cout << "the matrix is null with a 0.7 error : " << mat10.isNull(0.7) << endl;
    cout << Matrix() << endl;
    cout << "the matrix is null : " << Matrix().isNull(0.7) << endl;


    /* cout << "\n-----------Reverse matrix-----------" << endl;
    try {
        reverse = inverse( test, 100000, 0.00000001 );
        cout << "original matrix" << endl << test << endl;
        cout << "reversed matrix" << endl << reverse << endl;
        cout << "the product" << endl << test * reverse << endl;
    } catch ( const char * err ) {
        cerr << err << endl;
    } */



    
    return 0;
}