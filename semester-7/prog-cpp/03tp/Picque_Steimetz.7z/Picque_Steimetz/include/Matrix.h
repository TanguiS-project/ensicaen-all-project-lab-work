#ifndef __MATRIX_H__
#define __MATRIX_H__
#include <iostream>
#include <cstring>

class Matrix
{
private:
    double *_matrix;
    int _rows;
    int _columns;

public:
    Matrix();
    Matrix( const int height, const int width);
    Matrix( const int height, const int width, const double *table);
    Matrix(const Matrix &matrix);
    Matrix( Matrix && matric );
    ~Matrix();
    Matrix & operator=(const Matrix &matrix);
    Matrix & operator=( Matrix && matrix);
    double * operator[]( const int position );
    double & operator()( const int height, const int width );
    double operator()( const int height, const int width ) const;
    Matrix operator+( const Matrix & matrix ) const;
    Matrix operator-( const Matrix & matrix ) const;
    Matrix operator-() const;
    Matrix operator*( const Matrix & matrix ) const;
    friend std::ostream &operator<<( std::ostream &, const Matrix & );
    friend std::istream &operator>>(std::istream &, Matrix &);

    bool testSquareMatrix() const;
    Matrix getTranspose() const;
    bool isNull( const double epsilon );
    Matrix createId()const;

};

std::istream &operator<<(std::istream &, const Matrix &);
std::ostream &operator>>(std::ostream &, Matrix &);
Matrix createId( const int size );
Matrix inverse( const Matrix & M, const int n, const double epsilon );

#endif