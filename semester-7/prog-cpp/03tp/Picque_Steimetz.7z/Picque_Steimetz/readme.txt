Tangui STEIMETZ
Kylian PICQUE


                    Compte Rendu



-----------------
Compilation et exécution :
    
    -Pour compiler, entrez dans votre terminal bash la commande "make".
    
    -Pour exécuter, entrez dans votre terminal la commande "./make run".

    -Pour supprimer les fichier objets, entrez la commande "make clean"

    -Pour supprimer les fichier objets et exécutables, entrez la commande "make
distclean"

    -Pour ziper le ficher, entrer la commande "make zip"


-----------------
Question 1.2 :

    -L'opérateur [] rompt l'encpsulation car il expose une ligne entière de la matrice

    -L'opérateur qui peut remplacer l'opérateur [] est le (). En effet si l'on retourne une référence,
on peut obtenir une valeur ou la modifier sans mettre en danger les autres. Nous avons aussi fait cette méthode en const, dans le cas
où l'on juste accéder à une valeur sans la modifier. Le but de cela est d'utiliser des matrices constantes.


-----------------
Question 2.1 :

```bash
const&& 00
const&& 00
const&& 00
op&& 00
const&& 00
const&& 00
```
    -Le premier constructeur de recopie par déplacemment correspond au resultat du produit matriciel de a par b

    -Le second constructeur de recopie par déplacemment correspond à la créaction de d à partir du résultat du produn a par b

    -Le troisième constructeur de recopie par déplacemment correspond au resultat du produit matriciel de a par b

    -L'opérateur d'affectation correspond à la création de c à partir du résultat de a par b

    -L'avant dernier constructeur de recopie par déplacemment correspond au resultat du produit matriciel de c par c

    -Le dernier constructeur de recopie par déplacemet est celui de l'argument qui est recopié dans la fonction
