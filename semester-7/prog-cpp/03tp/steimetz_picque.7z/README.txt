STEIMETZ Tangui & PICQUE Kylian- Rapport tp02 C++

3.2 : par reference

3.5 : 
sortie programme : 
    +++Complex()
    +++Complex(1,1)
    +++Complex(2,2)
Calling foo()
    rrrComplex(1+i.1)
    rrrComplex(0+i.0)
    +++Complex(10,10)
    op=Complex(0+i.0)
    op=Complex(1+i.1)
    op=Complex(1+i.1)
    ---Complex(1+i.1)
    ---Complex(0+i.0)
    ---Complex(1+i.1)
End calling foo()

--> Com :
- Avant foo : 
Creation des trois complexes 'z_n'
- Dans foo : 
rrr : recopie des deux arguments 'Complex';
+++ : Creation du nouveau Complex(10, 10);
op= : affectation de 'a' puis 'b' à 'z' puis l'affectation au return;
--- : destruction des 'z_n'