#include "Matrix.h"

using namespace std;

#define elementIndex(x, width, y) (x * width + y)
#define rowIndex(x, y) (x * y)

Matrix::Matrix( const int width, const int height ) : _columns(width), _rows(height) 
{
    if ( !_columns ) {
        _tab = nullptr;
        return;
    }
    _tab = new double[_columns * _rows];
}

Matrix::Matrix( const int width, const int height, const double* tab ) :  _columns(width), _rows(height)
{
    _tab = new double[_columns * _rows];
    memcpy( _tab, tab, _columns * _rows * sizeof( double ) );
}

Matrix::Matrix( const Matrix& matrix ) : _columns(matrix._columns), _rows(matrix._rows)
{
    _tab = new double[_columns * _rows];
    memcpy( _tab, matrix._tab, _columns * _rows * sizeof( double ) );
}

Matrix::Matrix( Matrix&& matrix )
{
    _tab = matrix._tab;
    _rows = matrix._rows;
    _columns = matrix._columns;
    matrix._tab = nullptr;
}


Matrix::~Matrix()
{
    cout << "detruit" << endl;
    delete[] _tab;
}

Matrix& Matrix::operator=( const Matrix& m )
{
    _columns = m._columns;
    _rows = m._rows;
    delete[] _tab;
    _tab = new double[_columns * _rows];
    memcpy( _tab, m._tab, _columns * _rows * sizeof( double ) );
    return *this;
}

Matrix& Matrix::operator=( Matrix&& m )
{
    cout << "   ===()\n";
    delete[] _tab;
    _tab = m._tab;
    m._tab = nullptr;
    return *this;
}

Matrix Matrix::operator+( Matrix& m )
{
    if ( !isSameSize(m) ) {
        cout << "err dim" << endl;
        return *this;
    }
    Matrix result(_columns, _rows );
    for ( int x = 0; x < _rows; x++ ) {
        for ( int y = 0; y < _columns; y++ ) {
            result(x, y) = (*(this))(x, y) + m(x, y);
        }
    }
    return result;
}

Matrix Matrix::operator-( )
{
    Matrix result(_columns, _rows );
    for ( int x = 0; x < _rows; x++ ) {
        for ( int y = 0; y < _columns; y++ ) {
            result(x, y) = -(*(this))(x, y);
        }
    }
    return result;
}

Matrix Matrix::operator-( Matrix& m )
{
    if ( !isSameSize(m) ) {
        cout << "err dim" << endl;
        return *this;
    }
    Matrix result(_columns, _rows );
    for ( int x = 0; x < _rows; x++ ) {
        for ( int y = 0; y < _columns; y++ ) {
            result(x, y) = (*(this))(x, y) - m(x, y);
        }
    }
    return result;
}

Matrix Matrix::operator*( Matrix& m )
{
    cout << "rows = " << _columns << " m.columns = " << m._rows << endl;
    if ( _columns != m._rows ) {
        cout << "err dim" << endl;
        exit( EXIT_FAILURE );
    }
    Matrix result(_rows, m._columns );
    for ( int x = 0; x < _rows; x++ ) {
        for ( int y = 0; y < m._columns; y++ ) {
            double tmp = 0.;
            for ( int i = 0; i < _rows; i++ ) {
                tmp += (*(this))(x, i) * m(i, y);
            }
            result(x, y) = tmp;
        }
    }
    return result;
}




double* Matrix::operator[]( const int line )
{
    return _tab + rowIndex(_columns, line);
}

double& Matrix::operator()( const int x, const int y )
{
    if ( !isInTab( x, y ) ) {
        cout << "err not in range : " << "x = " << x << " rows = " << _rows << " y = " << y << " columns = " << _columns << endl;
        exit( EXIT_FAILURE );
    }
    return _tab[elementIndex( x, _columns, y )];
}





string Matrix::toString() const
{
    stringstream result;
    result << "Matrix size : (" << _columns << ", " << _rows << ")\n[";
    for ( int x = 0; x < _rows; x++ ) {
        x == 0 ? result << "[" : result << " [";
        for ( int y = 0; y < _columns; y++ ) {
            char buff[255];
            if ( x == _rows-1 && y == _columns-1 ) {
                sprintf( buff, "% *.3f ]", 10, _tab[elementIndex(x, _columns, y)] );
            } else if ( y == _columns-1 ) {
                sprintf( buff, "% *.3f ],\n", 10, _tab[elementIndex(x, _columns, y)] );
            } else {
                sprintf( buff, "% *.3f, ", 10, _tab[elementIndex(x, _columns, y)] );
            }
            result << buff;
        }
    }
    result << "]";
    return result.str();
}

bool Matrix::isSameSize( const Matrix& m ) const
{
    return _columns == m._columns && _rows == m._rows;
}

bool Matrix::isNull() const
{
    return _tab == nullptr;
}

bool Matrix::isInTab( const int x, const int y ) const
{
    //cout << "err not in range : " << "x = " << x << " rows = " << _rows << " y = " << y << " columns = " << _columns << endl;
    return x <= _rows && y <= _columns;
}




ostream& operator<<( ostream& stream, const Matrix & matrix )
{
    return (stream << matrix.toString() );
}

