#include "Matrix.h"
#include <iostream>

using namespace std;

int main( void )
{


    double tab[] = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    double tab5[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24};
    double tab6[] = {0, 1, 2, 3, 4, 5};


    Matrix matrix(5, 5, tab5);

    Matrix matrix2(3, 3, tab);

    matrix = matrix2;

    matrix = -matrix;

    Matrix matrix3 = matrix2 + matrix2;
    cout << "Matrix2 : \n" << matrix2 << endl;
    cout << "addition : \n" << matrix3 << endl;

    Matrix matrix4 = matrix2 * matrix2;
    cout << "Matrix2 : \n" << matrix2 << endl;
    cout << "multiplication : \n" << matrix4 << endl;
    //cout << "produit : \n" << matrix4 << endl;

    Matrix matrix5(2, 3, tab6);
    Matrix matrix6(3, 2, tab6);
    cout << matrix5 << endl;
    cout << matrix6 << endl;

    Matrix matrix7 = matrix5 * matrix6;
    cout << matrix7 << endl;

    return 1;
}