#ifndef __MATRIX_HH__
#define __MATRIX_HH__

#include <iostream>
#include <cstring>
#include <sstream>

class Matrix {
private:
    /* data */
    int _columns;
    int _rows;
    double* _tab;
public:
    Matrix( const int width = 0, const int height = 0 );
    Matrix( const int width, const int height, const double* tab );
    Matrix( const Matrix& matrix );
    Matrix( Matrix&& matrix );
    ~Matrix();
    Matrix& operator=( const Matrix& m );
    Matrix& operator=( Matrix&& m );
    Matrix operator+( Matrix& m );
    Matrix operator-( Matrix& m );
    Matrix operator-();
    Matrix operator*( Matrix& m );
    double* operator[]( const int line ); // do not respect encapsulation
    double& operator()( const int x, const int y );

    std::string toString() const;
    bool isSameSize( const Matrix& m ) const;
    bool isNull() const;
    bool isInTab( const int x, const int y ) const;
    double getElementTab( const int x, const int y ) const;
    void setElementTab( const int x, const int y, const double element ) const;
};


std::ostream& operator<<( std::ostream& stream, const Matrix & matrix );







#endif // __MATRIX_HH__