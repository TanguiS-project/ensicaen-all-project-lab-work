public class Orc extends Soldier {
    public Orc( int x, int y ) {
        super("orc.png", x, y);
    }
}
