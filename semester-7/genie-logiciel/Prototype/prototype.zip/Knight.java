public class Knight extends Soldier {
    public Knight( int x, int y ) {
        super("knight.png", x, y);
    }
}
