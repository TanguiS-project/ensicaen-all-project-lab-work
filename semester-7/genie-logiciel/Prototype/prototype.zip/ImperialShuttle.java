public class ImperialShuttle extends Soldier {
    public ImperialShuttle( int x, int y ) {
        super("shuttle.png", x, y);
    }

}