public class Mario extends Soldier {
    public Mario( int x, int y ) {
        super("mario.png", x, y);
    }

    public Mario clone() {
        return new Mario(super.getX(), super.getY());
    }
}
