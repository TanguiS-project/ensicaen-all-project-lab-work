public class SuperMario extends Scene {
    public SuperMario() {
        super("supermario.jpg", 780, 470, 0, 300);
//        super.s1 = new Mario(0, 0);
//        super.s2 = new Goomba(0, 0);
    }
}
