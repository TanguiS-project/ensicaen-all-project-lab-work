public class LordOfTheRing extends Scene {
    public LordOfTheRing() {
        super("lotr.jpg", 740, 420, 0, 280);
    }
}
