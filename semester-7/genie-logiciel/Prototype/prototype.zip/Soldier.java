public abstract class Soldier {
    private final String _image;
    private int _px;
    private int _py;

    public Soldier( String s, int x, int y ) {
        _image = s;
        _px = x;
        _py = y;
    }

    public void paintOver( MyImage i ) {
        i.paintOver(_image, _px, _py);
    }

    public void setX( int x ) {
        _px = x;
    }

    public void setY( int y ) {
        _py = y;
    }

    public int getX() {
        return _px;
    }

    public int getY() {
        return _py;
    }
}
