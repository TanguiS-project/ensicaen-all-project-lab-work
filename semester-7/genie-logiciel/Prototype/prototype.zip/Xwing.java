public class Xwing extends Soldier {
    public Xwing( int x, int y ) {
        super("xwing.png", x, y);
    }
}