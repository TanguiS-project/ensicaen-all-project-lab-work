public class StarWars extends Scene {
    public StarWars() {
        super("starwars.jpg", 792, 241, 0, 0);
    }
}