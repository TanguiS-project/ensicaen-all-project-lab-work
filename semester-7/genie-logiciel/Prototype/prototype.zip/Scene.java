import java.util.ArrayList;
import java.util.Iterator;

public abstract class Scene {
    private final String _decor;
    private final int _maxX;
    private final int _maxY;
    private final int _minX;
    private final int _minY;
    private final ArrayList<Soldier> _characters;

    public Scene( String d, int maxx, int maxy, int minx, int miny ) {
        _decor = d;
        _maxX = maxx;
        _maxY = maxy;
        _minX = minx;
        _minY = miny;
        _characters = new ArrayList<>();
    }

    public int getMaxX() {
        return _maxX;
    }

    public int getMaxY() {
        return _maxY;
    }

    public int getMinX() {
        return _minX;
    }

    public int getMinY() {
        return _minY;
    }

    public void addSoldier( Soldier s ) {
        _characters.add(s);
    }

    public void render() {
        MyImage m = new MyImage(_decor);
        Iterator<Soldier> i = _characters.iterator();
        while (i.hasNext()) {
            Soldier s = i.next();
            s.paintOver(m);
        }
        m.display();
    }
}
