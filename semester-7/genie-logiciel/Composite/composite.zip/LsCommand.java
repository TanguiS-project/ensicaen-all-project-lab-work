import java.io.File;

public final class LsCommand {

    public static void main( String[] args ) {
        String folderName = ".";
        File folder = new File(folderName);
        System.out.println("ls " + folder.getAbsolutePath());
        FileComposite fileComposite = new MyFolder(folder);
        fileComposite.print();
    }
}