public class SystemValues {
    public static final String PROJECT_PATH = "";
}
