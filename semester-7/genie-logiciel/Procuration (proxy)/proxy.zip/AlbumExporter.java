interface AlbumExporter {
    void displayAlbum();
}
