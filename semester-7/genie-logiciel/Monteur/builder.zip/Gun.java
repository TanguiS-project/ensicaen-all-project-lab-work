public class Gun {
    private final int _power;
    private final String _name;
    private final double _weight;
    private boolean _step1;
    private boolean _step2;
    private boolean _step3;
    private boolean _step4;

    public Gun() {
        _power = 15;
        _name = "Gun";
        _weight = 0.75;
    }

    @Override
    public String toString() {
        return _name;
    }

    public void loadMeshGPU() {
        System.out.println("Loading file weapons/gun/gun.mesh in GPU");
    }

    public void paintMeshGPU() {
        System.out.println("Painting in black all parts of Gun for GPU.");
    }

    public void positionRightHand() {
        System.out.println("Join right hand with gun's handle.part");
    }

    public void loadMeshCPU() {
        System.out.println("Loading file weapons/gun/gun.mesh in CPU");
    }

    public void paintMeshCPU() {
        System.out.println("Painting in black all parts of Gun for CPU.");
    }

    public void preloadMeshInCache() {
        System.out.println("Preloading the mesh in the CPU's cache.");
    }
}
