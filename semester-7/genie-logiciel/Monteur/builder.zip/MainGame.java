import java.util.*;

public class MainGame {
    public static void main( String[] args ) {
        List<Orders> orders = new ArrayList<>();
        orders.add(Orders.PAINT_CPU);
        orders.add(Orders.LOAD_CPU);
        orders.add(Orders.LOAD_CACHE);
        orders.add(Orders.RIGHT_HAND);
        orders.add(Orders.RIGHT_FOOT);
        orders.add(Orders.LEFT_HAND);
        orders.add(Orders.LEFT_FOOT);

        Gun gun = new Gun();
        Iterator<Orders> i = orders.iterator();
        while (i.hasNext()) {
            switch (i.next()) {
                case PAINT_CPU:
                    gun.paintMeshCPU();
                    break;
                case LOAD_CPU:
                    gun.loadMeshCPU();
                    break;
                case LOAD_CACHE:
                    gun.preloadMeshInCache();
                    break;
                case RIGHT_HAND:
                    gun.positionRightHand();
                    break;
                case LOAD_GPU:
                    gun.loadMeshGPU();
                    break;
                case PAINT_GPU:
                    gun.paintMeshGPU();
                    break;
                default:
                    break;
            }
        }
    }
}
