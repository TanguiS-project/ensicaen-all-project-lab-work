public class Saw {
    private final int _power;
    private final String _name;
    private final double _weight;
    private final int _powerSecondaryAttack;

    public Saw() {
        _power = 45;
        _powerSecondaryAttack = 70;
        _name = "Saw";
        _weight = 5.0;
    }

    @Override
    public String toString() {
        return _name;
    }

    public void loadMeshGPU() {
        System.out.println("Loading file weapons/saw/saw.mesh in GPU");
    }

    public void paintMeshGPU() {
        System.out.println("Painting all parts of Saw for GPU.");
    }

    public void loadMeshCPU() {
        System.out.println("Loading file weapons/saw/saw.mesh in CPU");
    }

    public void paintMeshCPU() {
        System.out.println("Painting all parts of Saw for CPU.");
    }

    public void preloadMeshInCache() {
        System.out.println("Preloading the mesh of saw in the CPU's cache.");
    }

    public void positionRightHand() {
        System.out.println("Join right hand with saw's handle.part");
    }

    public void positionLeftHand() {
        System.out.println("Join left hand with saw's side_handle.part");
    }
}
