public class Bicycle {
    private final String _name;
    private final double _weight;
    private final int _step;

    public Bicycle() {
        _name = "Pink bicycle";
        _weight = 2.0;
        _step = 0;
    }

    @Override
    public String toString() {
        return _name;
    }

    public void loadMeshGPU() {
        System.out.println("Loading file weapons/bike/bike.mesh in GPU");
    }

    public void paintMeshGPU() {
        System.out.println("Painting all parts of Bike for GPU.");
    }

    public void preloadMeshInCache() {
        System.out.println("Preloading the mesh of bike in the CPU's cache.");
    }

    public void positionRightHand() {
        System.out.println("Join right hand with right handle");
    }

    public void positionLeftHand() {
        System.out.println("Join left hand with left handle");
    }

    public void positionRightFoot() {
        System.out.println("Join right foot with right pedal");
    }

    public void positionLeftFoot() {
        System.out.println("Join left foot with left pedal");
    }
}
