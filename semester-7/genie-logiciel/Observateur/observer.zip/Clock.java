import java.util.Calendar;

public class Clock extends Thread {
    private Calendar _calendar;
    private String _time = "";

    public Clock() {
        Thread t = new Thread(this);
        t.start();
    }

    @Override
    public void run() {
        while (true) {
            _calendar = Calendar.getInstance();
            _time = _calendar.get(Calendar.HOUR_OF_DAY) + " : "
                    +
                    (_calendar.get(Calendar.MINUTE) < 10
                            ? "0" + _calendar.get(Calendar.MINUTE)
                            : _calendar.get(Calendar.MINUTE))
                    + " : "
                    +
                    (_calendar.get(Calendar.SECOND) < 10
                            ? "0" + _calendar.get(Calendar.SECOND)
                            : _calendar.get(Calendar.SECOND));
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}