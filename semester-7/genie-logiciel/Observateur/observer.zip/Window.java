import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.*;

public class Window extends JFrame {
    private final JLabel _label = new JLabel();
    private Clock _clock;

    public static void main( String[] args ) {
        Window window = new Window();
        window.setVisible(true);
    }

    public Window() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setSize(200, 80);
        _clock = new Clock();
        Font police = new Font("DS-digital", Font.BOLD, 30);
        _label.setFont(police);
        _label.setHorizontalAlignment(SwingConstants.CENTER);
        getContentPane().add(_label, BorderLayout.CENTER);
    }
}
