public class Main {

    public static void main( String[] args ) {
        SuperLogo reneLaTaupe = new ReneLaTaupe();
        MyImage image = reneLaTaupe.getLogo();
        image.paintOver("img/hat.png", 280, 42);
        image.display();
    }
}
