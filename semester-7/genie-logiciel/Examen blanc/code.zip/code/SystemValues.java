public class SystemValues {
    private SystemValues() {
    }

    public static final String PROJECT_PATH = "";
}
