public class Main4 {
    public static void main( String[] args ) {
//        Menu menu = new Menu();
//        menu.execute();
    }
}
