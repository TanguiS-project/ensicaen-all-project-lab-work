public interface Character {
    MyImage getImage();

    int[] getRightHand();

    int[] getLeftHand();

    int[] getHead();

    int[] getTorso();
}
