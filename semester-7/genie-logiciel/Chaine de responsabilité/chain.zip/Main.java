public class Main {
    public static void main( String[] args ) {
        ResultPool results = new ResultPool();
        ProcessorQuick processor = new ProcessorQuick(results);
        processor.runTask(512);
        processor.runTask(1000);
        results.printResult();
    }
}
